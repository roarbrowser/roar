// ==UserScript==
// @name        Hello VM
// @namespace   fixtures
// @version     1.2
// @match       https://example.com/*
// @grant       GM_getValue
// ==/UserScript==
console.log('hello', GM_getValue('count'));
