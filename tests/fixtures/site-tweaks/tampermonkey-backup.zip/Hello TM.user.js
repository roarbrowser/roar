// ==UserScript==
// @name        Hello TM
// @namespace   fixtures
// @version     2.0
// @match       https://example.org/*
// @grant       GM_setValue
// ==/UserScript==
GM_setValue('seen', true);
